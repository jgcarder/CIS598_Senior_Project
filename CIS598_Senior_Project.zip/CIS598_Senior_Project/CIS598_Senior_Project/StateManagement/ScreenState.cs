﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CIS598_Senior_Project.StateManagement
{
    public enum ScreenState
    {
        TransitionOn,
        Active,
        TransitionOff,
        Hidden
    }
}
